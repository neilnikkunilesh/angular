import { ApiService } from './../ApiService';
import { NgForm } from '@angular/forms';
import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-pricing-admin',
  templateUrl: './pricing-admin.component.html',
  styleUrls: ['./pricing-admin.component.css']
})
export class PricingAdminComponent implements OnInit {

  apiText ='';
  apiResponse='';
  allowSendApi = false;
  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
  }

  onSubmit(apiForm: NgForm){
    this.apiText = apiForm.value.apiText;
    console.log(this.apiText);
    return this.apiService.postUnitPriceCost(this.apiText).subscribe(
      response =>{
        console.log('Api Response = ', response);
        this.apiResponse = JSON.stringify(response);
      },
      err=>{
        console.log("Error in get data", err);
        alert("Error");
      }

    );
  }
}
