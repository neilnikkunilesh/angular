import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormArray, NgForm } from '@angular/forms';

@Component({
  selector: 'app-collection-editor',
  templateUrl: './collection-editor.component.html',
  styleUrls: ['./collection-editor.component.css']
})
export class CollectionEditorComponent implements OnInit{

// formGroup Directive: Bind <form> element to FormGroup instance
collectionForm: FormGroup;

// template driven variable
firstName = '';
lastName = '';
constructor() { }

// tslint:disable-next-line:typedef
ngOnInit() {
  this.collectionForm = new FormGroup({
    firstName: new FormControl("", [Validators.required, Validators.minLength(10)]),
    lastName: new FormControl("", Validators.required)
  });
}

onSubmit(): void {
  console.log(this.collectionForm.value);
  this.firstName = this.collectionForm.controls.firstName.value
  this.lastName = this.collectionForm.controls.lastName.value
}

onSave(myForm: NgForm){
  this.firstName = myForm.value.first;
  this.lastName = myForm.value.last;
  console.log(myForm.value);
  console.log("Full Name : "+this.firstName+" "+this.lastName)
}

}
