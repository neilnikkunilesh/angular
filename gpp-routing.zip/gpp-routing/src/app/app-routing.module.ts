import { PricingAdminComponent } from './pricing-admin/pricing-admin.component';
import { CollectionComponent } from './collection/collection.component';
import { VendorComponent } from './vendor/vendor.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: 'vendor', component: VendorComponent},
  { path: 'collection', component: CollectionComponent},
  { path: 'pricing-admin', component: PricingAdminComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [VendorComponent, CollectionComponent, PricingAdminComponent]
